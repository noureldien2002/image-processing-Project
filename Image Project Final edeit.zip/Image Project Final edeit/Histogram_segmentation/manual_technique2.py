from PIL import Image
import numpy as np
import matplotlib.pyplot as plt

def load_image(path):
    """Load an image from a file and convert to grayscale."""
    img = Image.open(path).convert("L")  # Convert to grayscale
    return np.array(img)

# Function to compute the histogram of an image
def compute_histogram(image):
    histogram = [0] * 256  # Initialize a list to store counts of each intensity level
    for row in image:
        for pixel in row:
            histogram[pixel] += 1  # Increment the count of the corresponding pixel intensity
    return histogram

# Function to manually segment the image based on thresholds
def manual_threshold_segmentation(image, low_threshold, high_threshold, value=1):
    
    segmented_image = np.zeros_like(image)  # Initialize an empty image for segmentation
    
    # Apply the threshold to segment the image
    for row in range(image.shape[0]):
        for col in range(image.shape[1]):
            if low_threshold <= image[row, col] <= high_threshold:
                segmented_image[row, col] = value * 255  # Set pixel to white (255) if within range

    return segmented_image

# Function to display the original image, histogram, and segmented image
def display_images_and_histogram(original, histogram, segmented):
    # Visualization
    plt.figure(figsize=(12, 6))

    # Display the original image
    plt.subplot(1, 3, 1)
    plt.title("Original Image")
    plt.imshow(original, cmap='gray')

    # Display the histogram with vertical bars
    plt.subplot(1, 3, 2)
    plt.title("Histogram")
    x = np.arange(len(histogram))  # x-axis for pixel intensities (0-255)
    plt.bar(x, histogram, width=1, color='black', edgecolor='gray')  # Use bar chart for the histogram
    plt.legend()

    # Display the segmented image
    plt.subplot(1, 3, 3)
    plt.title("Segmented Image")
    plt.imshow(segmented, cmap='gray')

    plt.tight_layout()
    plt.show()
    
def process_manual_segmentation(image_path):

    # Main program execution

    image = load_image(image_path)

    # Step 1: Compute the histogram of the original image
    histogram = compute_histogram(image)

    # Step 2: Input thresholds from the user
    low_threshold = int(input("Enter the low threshold value (0-255): "))
    high_threshold = int(input("Enter the high threshold value (0-255): "))

    # Step 3: Perform manual threshold segmentation
    segmented_image = manual_threshold_segmentation(image, low_threshold, high_threshold)

    # Step 4: Display the original image, histogram, and segmented image
    display_images_and_histogram(image, histogram, segmented_image)
    
process_manual_segmentation(input("Enter image path: "))
