import numpy as np
import matplotlib.pyplot as plt
from PIL import Image

def load_image(path):
    """Load an image from a file and convert to grayscale."""
    img = Image.open(path).convert("L")  # Convert to grayscale
    return np.array(img)

# Functions for basic operations from earlier techniques
def compute_histogram(image, num_bins=256):
    """Compute the histogram of the image manually."""
    histogram = [0] * num_bins
    rows, cols = image.shape
    for i in range(rows):
        for j in range(cols):
            histogram[image[i, j]] += 1
    return np.array(histogram)

def smooth_histogram(histogram, window_size=5):
    """Smooth the histogram using a moving average filter."""
    half_window = window_size // 2
    smoothed = np.zeros_like(histogram)
    for i in range(len(histogram)):
        start = max(0, i - half_window)
        end = min(len(histogram), i + half_window + 1)
        smoothed[i] = sum(histogram[start:end]) / (end - start)
    return smoothed

def find_peaks(histogram, min_spacing=10):
    """Find the two most prominent peaks with a minimum spacing."""
    peaks = []
    for i in range(1, len(histogram) - 1):
        if histogram[i] > histogram[i - 1] and histogram[i] > histogram[i + 1]:
            peaks.append((i, histogram[i]))

    # Sort peaks by value and apply spacing constraint
    peaks = sorted(peaks, key=lambda x: x[1], reverse=True)
    selected_peaks = []
    for peak in peaks:
        if not selected_peaks or all(abs(peak[0] - p[0]) >= min_spacing for p in selected_peaks):
            selected_peaks.append(peak)
        if len(selected_peaks) == 2:
            break
    return selected_peaks

def determine_background_and_object(peaks, histogram):
    """Determine which peak corresponds to the background."""
    areas = [sum(histogram[max(0, p[0]-10):p[0]+10]) for p in peaks]
    if areas[0] > areas[1]:
        return peaks[0], peaks[1]
    else:
        return peaks[1], peaks[0]

def calculate_thresholds(peak1, peak2):
    """Calculate high and low threshold values from peaks."""
    return min(peak1[0], peak2[0]), max(peak1[0], peak2[0])

def segment_image(image, low_thresh, high_thresh):
    """Segment the image based on low and high thresholds."""
    segmented = np.zeros_like(image)
    segmented[image >= low_thresh] = 255
    segmented[image < high_thresh] = 0
    return segmented

def compute_means(image, segmented_image):
    """Compute the mean pixel value for the background and object."""
    # Convert image array to a higher data type to avoid overflow
    image = image.astype(np.int64)
    
    background_pixels = image[segmented_image == 0]
    object_pixels = image[segmented_image == 255]
    
    # Compute mean values safely
    background_mean = sum(background_pixels) // len(background_pixels) if len(background_pixels) > 0 else 0
    object_mean = sum(object_pixels) // len(object_pixels) if len(object_pixels) > 0 else 255
    
    return background_mean, object_mean

def display_images_and_histogram(original_image, histogram, smoothed_histogram, segmented_img, final_segmented_img): 
    # Visualization
    plt.figure(figsize=(15, 8))
    plt.subplot(1, 4, 1)
    plt.title("Original Image")
    plt.imshow(original_image, cmap='gray')

    plt.subplot(1, 4, 2)
    plt.title("Histogram")
    plt.plot(histogram, label="Histogram")
    plt.plot(smoothed_histogram, label="Smoothed Histogram", color='orange')
    plt.legend()

    plt.subplot(1, 4, 3)
    plt.title("Segmented (First Pass)")
    plt.imshow(segmented_img, cmap='gray')

    plt.subplot(1, 4, 4)
    plt.title("Segmented (Second Pass)")
    plt.imshow(final_segmented_img, cmap='gray')

    plt.tight_layout()
    plt.show()


# Adaptive Histogram Technique
def process_adaptive_histogram_technique(image_path, min_spacing=10, smoothing_window=5):
    """Process the image using the adaptive histogram technique."""
    # Load the image
    image = load_image(image_path)

    # First pass: Peak-based thresholding
    histogram = compute_histogram(image)
    smoothed_histogram = smooth_histogram(histogram, window_size=smoothing_window)
    peaks = find_peaks(smoothed_histogram, min_spacing)
    background_peak, object_peak = determine_background_and_object(peaks, smoothed_histogram)
    low_thresh, high_thresh = calculate_thresholds(background_peak, object_peak)
    segmented_image = segment_image(image, low_thresh, high_thresh)

    # Second pass: Adaptive refinement
    background_mean, object_mean = compute_means(image, segmented_image)
    low_thresh = background_mean
    high_thresh = object_mean
    final_segmented_image = segment_image(image, low_thresh, high_thresh)
    
    display_images_and_histogram(image, histogram, smoothed_histogram, segmented_image, final_segmented_image)


process_adaptive_histogram_technique(input("Enter image path: "), smoothing_window=7)
