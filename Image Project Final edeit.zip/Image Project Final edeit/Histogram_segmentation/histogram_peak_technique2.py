import numpy as np
import matplotlib.pyplot as plt
from PIL import Image

def load_image(path):
    """Load an image from a file and convert to grayscale."""
    img = Image.open(path).convert("L")  # Convert to grayscale
    return np.array(img)

def compute_histogram(original_image, num_bins=256):
    """Compute the histogram of the image manually."""
    histogram = [0] * num_bins
    rows, cols = original_image.shape
    for i in range(rows):
        for j in range(cols):
            histogram[original_image[i, j]] += 1
    return np.array(histogram)

def find_peaks(histogram, min_spacing=10):
    """Find the two most prominent peaks with a minimum spacing."""
    peaks = []
    for i in range(1, len(histogram) - 1):
        # Check if current bin is a peak
        if histogram[i] > histogram[i - 1] and histogram[i] > histogram[i + 1]:
            peaks.append((i, histogram[i]))

    # Sort peaks by value and apply spacing constraint
    peaks = sorted(peaks, key=lambda x: x[1], reverse=True)
    selected_peaks = []
    for peak in peaks:
        if not selected_peaks or all(abs(peak[0] - p[0]) >= min_spacing for p in selected_peaks):
            selected_peaks.append(peak)
        if len(selected_peaks) == 2:  # Only need two peaks
            break
    return selected_peaks

def determine_background_and_object(peaks, histogram):
    """Determine which peak corresponds to the background."""
    areas = [sum(histogram[max(0, p[0]-10):p[0]+10]) for p in peaks]
    # The larger area corresponds to the background
    if areas[0] > areas[1]:
        return peaks[0], peaks[1]
    else:
        return peaks[1], peaks[0]

def apply_threshold(original_image, low, high):
    """Segment the image using high and low thresholds."""
    segmented = np.zeros_like(original_image)
    segmented[original_image >= low] = 255
    segmented[original_image < low] = 0
    return segmented

def display_images_and_histogram(original_image, histogram, segmented_img, low_thresh, high_thresh, peaks):

    # Visualization
    plt.figure(figsize=(12, 6))

    # Display the original image
    plt.subplot(1, 3, 1)
    plt.title("Original Image")
    plt.imshow(original_image, cmap='gray')

    # Display the histogram with vertical bars
    plt.subplot(1, 3, 2)
    plt.title("Histogram")
    x = np.arange(len(histogram))  # x-axis for pixel intensities (0-255)
    plt.bar(x, histogram, width=1, color='black', edgecolor='gray')  # Use bar chart for the histogram
    plt.scatter(*zip(*peaks), color='red', label="Peaks")  # Overlay peaks
    plt.axvline(x=low_thresh, color='green', linestyle='--', label="Low Threshold")  # Low threshold line
    plt.axvline(x=high_thresh, color='blue', linestyle='--', label="High Threshold")  # High threshold line
    plt.legend()

    # Display the segmented image
    plt.subplot(1, 3, 3)
    plt.title("Segmented Image")
    plt.imshow(segmented_img, cmap='gray')

    plt.tight_layout()
    plt.show()


# Test the implementation

def process_peak_technique(image_path, min_spacing=10):
    
    image = load_image(image_path)

    # Compute the histogram
    hist = compute_histogram(image)

    # Find peaks
    peaks = find_peaks(hist, min_spacing=10)

    # Determine background and object
    background_peak, object_peak = determine_background_and_object(peaks, hist)

    # Calculate thresholds
    low_threshold = (background_peak[0] + object_peak[0]) // 2
    high_threshold = max(background_peak[0], object_peak[0])

    # Segment the image
    segmented_image = apply_threshold(image, low_threshold, high_threshold)

    #display original image + histogram + segmented image
    display_images_and_histogram(image, hist, segmented_image, low_threshold, high_threshold, peaks)
    
process_peak_technique(input("Enter image path: "))


