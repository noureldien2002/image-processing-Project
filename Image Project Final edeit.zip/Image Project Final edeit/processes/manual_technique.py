from PIL import Image
import numpy as np
import matplotlib.pyplot as plt

# Function to compute the histogram of an image
def compute_histogram(image):
    histogram = [0] * 256  # Initialize a list to store counts of each intensity level
    for row in image:
        for pixel in row:
            histogram[pixel] += 1  # Increment the count of the corresponding pixel intensity
    return histogram

def manual_threshold_segmentation(image, low_threshold, high_threshold, value=1):
    
    segmented_image = np.zeros_like(image)  
    
    # Apply the threshold to segment the image
    for row in range(image.shape[0]):
        for col in range(image.shape[1]):
            if low_threshold <= image[row, col] <= high_threshold:
                segmented_image[row, col] = value * 255  

    return segmented_image

    
def process_manual_segmentation(image, low_thresh, high_thresh):

    low_threshold = low_thresh
    high_threshold = high_thresh

    segmented_image = manual_threshold_segmentation(image, low_threshold, high_threshold)

    
    return segmented_image
