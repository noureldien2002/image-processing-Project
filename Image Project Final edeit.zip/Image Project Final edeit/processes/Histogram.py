import numpy as np
from PIL import Image
import matplotlib.pyplot as plt

def histogram_equalization(image):
    """
    Perform histogram equalization on a given image.

    Args:
        image (PIL.Image.Image): Input image, can be grayscale or RGB.

    Returns:
        (PIL.Image.Image, np.ndarray): Equalized image and its array representation.
    """
    # Convert the image to grayscale if not already
    if image.mode != 'L':
        image = image.convert('L')

    # Convert image to numpy array
    img_array = np.array(image)

    # Flatten the array and calculate histogram
    flat = img_array.flatten()
    hist, bins = np.histogram(flat, bins=256, range=[0, 256])

    # Compute the Cumulative Distribution Function (CDF)
    cdf = hist.cumsum()  # Cumulative sum of histogram values
    cdf_min = cdf[np.nonzero(cdf)].min()  # Non-zero minimum value of the CDF to avoid division by zero
    cdf_normalized = (cdf - cdf_min) * 255 / (cdf[-1] - cdf_min)  # Normalize to range [0, 255]

    # Map the original image through the normalized CDF
    equalized_img_array = np.interp(flat, bins[:-1], cdf_normalized).reshape(img_array.shape)

    # Convert the equalized array back to a PIL image
    equalized_image = Image.fromarray(equalized_img_array.astype(np.uint8))

    return equalized_image, equalized_img_array




def analyze_histogram_quality(image_array):
    # Calculate the histogram of the image
    hist, bins = np.histogram(image_array.flatten(), bins=256, range=[0, 256])

    total_pixels = np.sum(hist)
    dark_pixels = np.sum(hist[:50])  # Dark pixels (0-50)
    bright_pixels = np.sum(hist[200:])  # Bright pixels (200-255)

    # Check if the histogram is good or not
    if dark_pixels / total_pixels > 0.5:
        return "The histogram is not good: The image is too dark."
    elif bright_pixels / total_pixels > 0.5:
        return "The histogram is not good: The image is too bright."
    else:
        return "The histogram is good: The image has balanced brightness levels."


def plot_histogram_and_image(img_array, equalized_img_array, title1, title2):
    # Create a figure with two subplots (one for the image and one for the histogram)
    fig, ax = plt.subplots(1, 2, figsize=(15, 6))

    # Display the original image
    ax[0].imshow(img_array, cmap='gray')
    ax[0].set_title(f"Original Image ({title1})")
    ax[0].axis('off')

    # Plot the original image histogram
    ax1 = ax[1]
    ax1.hist(img_array.flatten(), bins=256, range=[0, 256], color='gray', alpha=0.7)
    ax1.set_title(f"Original Histogram ({title1})")
    ax1.set_xlabel('Pixel Intensity')
    ax1.set_ylabel('Frequency')

    # Show the plot
    plt.tight_layout()
    plt.show()

    # Plot for Equalized Image
    fig, ax = plt.subplots(1, 2, figsize=(15, 6))

    ax[0].imshow(equalized_img_array, cmap='gray')
    ax[0].set_title(f"Equalized Image ({title2})")
    ax[0].axis('off')

    ax1 = ax[1]
    ax1.hist(equalized_img_array.flatten(), bins=256, range=[0, 256], color='gray', alpha=0.7)
    ax1.set_title(f"Equalized Histogram ({title2})")
    ax1.set_xlabel('Pixel Intensity')
    ax1.set_ylabel('Frequency')

    # Show the plot
    plt.tight_layout()
    plt.show()

