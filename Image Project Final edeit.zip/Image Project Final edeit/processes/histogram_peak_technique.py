import numpy as np
import matplotlib.pyplot as plt
from PIL import Image

def compute_histogram(original_image, num_bins=256):
    histogram = [0] * num_bins
    rows, cols = original_image.shape
    for i in range(rows):
        for j in range(cols):
            histogram[original_image[i, j]] += 1
    return np.array(histogram)

def find_peaks(histogram, min_spacing=10):
    peaks = []
    for i in range(1, len(histogram) - 1):
        # Check if current bin is a peak
        if histogram[i] > histogram[i - 1] and histogram[i] > histogram[i + 1]:
            peaks.append((i, histogram[i]))

    # apply spacing constraint
    peaks = sorted(peaks, key=lambda x: x[1], reverse=True)
    selected_peaks = []
    for peak in peaks:
        if not selected_peaks or all(abs(peak[0] - p[0]) >= min_spacing for p in selected_peaks):
            selected_peaks.append(peak)
        if len(selected_peaks) == 2:  
            break
    return selected_peaks

def determine_background_and_object(peaks, histogram):
    areas = [sum(histogram[max(0, p[0]-10):p[0]+10]) for p in peaks]
    # The larger area corresponds to the background
    if areas[0] > areas[1]:
        return peaks[0], peaks[1]
    else:
        return peaks[1], peaks[0]

def apply_threshold(original_image, low, high):
    segmented = np.zeros_like(original_image)
    segmented[original_image >= low] = 255
    segmented[original_image < low] = 0
    return segmented


def process_peak_technique(image, min_spacing=10):

    hist = compute_histogram(image)

    peaks = find_peaks(hist, min_spacing=10)

    background_peak, object_peak = determine_background_and_object(peaks, hist)

    low_threshold = (background_peak[0] + object_peak[0]) // 2
    high_threshold = max(background_peak[0], object_peak[0])

    segmented_image = apply_threshold(image, low_threshold, high_threshold)

    return segmented_image


