import numpy as np
from PIL import Image, ImageTk
import tkinter as tk
from tkinter import filedialog, messagebox
from matplotlib import pyplot as plt
from processes.image_operations import add, subtract, invert
from processes.image_color import manual_grayscale
from processes.threshold import calculate_threshold
from processes.simple_halftoning import simple_halftone
from processes.advanced_halftone import advanced_halftone
from processes.Histogram import histogram_equalization, analyze_histogram_quality
from processes.Filtering_Image import conv, median_filter, mask_high_pass, mask_low_pass
from processes.simple_edge_detection import apply_edge_detection 
from processes.Advanced_Edge_Detection import homogeneity_operator, difference_operator, difference_of_gaussians, variance_operator, contrast_edge_detection, range_operator 
from processes.adaptive_histogram_technique import process_adaptive_histogram_technique 
from processes.histogram_peak_technique import process_peak_technique
from processes.histogram_valley_technique_with_smoothing import process_valley_technique
from processes.manual_technique import process_manual_segmentation

# Global variables
original_image = None
original_image_array = None

# Function to upload an image
def upload_image():
    global original_image, original_image_array

    file_path = filedialog.askopenfilename(filetypes=[("Image Files", "*.jpg;*.jpeg;*.png;*.bmp")])
    if file_path:
        try:
            original_image = Image.open(file_path)
            original_image.thumbnail((300, 300))  # Resize for display
            original_image_array = np.array(original_image.convert('L'), dtype=np.uint8)  # Convert to grayscale
            uploaded_image = ImageTk.PhotoImage(original_image)
            image_label.configure(image=uploaded_image, text="")  # Clear the text
            image_label.image = uploaded_image
            messagebox.showinfo("Success", "Image uploaded successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to upload image: {e}")

# Function to display a histogram
def display_histogram(image_array, title="Histogram"):
    plt.figure(figsize=(8, 4))
    plt.hist(image_array.flatten(), bins=256, color='blue', alpha=0.7)
    plt.title(title)
    plt.xlabel("Pixel Value")
    plt.ylabel("Frequency")
    plt.grid(True)
    plt.show()

# Function to get threshold inputs
def get_threshold_inputs():
    threshold_window = tk.Toplevel(root)
    threshold_window.title("Threshold Input")
    threshold_window.geometry("300x200")
    threshold_window.configure(bg=frame_bg_color)

    tk.Label(threshold_window, text="Low Threshold:", bg=frame_bg_color, fg=label_fg_color, font=("Helvetica", 12)).pack(pady=10)
    low_threshold_entry = tk.Entry(threshold_window, font=("Helvetica", 12))
    low_threshold_entry.pack(pady=5)

    tk.Label(threshold_window, text="High Threshold:", bg=frame_bg_color, fg=label_fg_color, font=("Helvetica", 12)).pack(pady=10)
    high_threshold_entry = tk.Entry(threshold_window, font=("Helvetica", 12))
    high_threshold_entry.pack(pady=5)

    def submit_thresholds():
        try:
            low_thresh = int(low_threshold_entry.get())
            high_thresh = int(high_threshold_entry.get())
            if low_thresh < 0 or high_thresh > 255 or low_thresh >= high_thresh:
                raise ValueError("Invalid threshold values.")
            threshold_window.destroy()
            process_manual_segmentation_action(low_thresh, high_thresh)
        except ValueError as ve:
            messagebox.showerror("Error", f"Invalid input: {ve}")

    submit_button = tk.Button(threshold_window, text="Submit", command=submit_thresholds, bg=button_bg_color, fg=button_fg_color, font=("Helvetica", 12))
    submit_button.pack(pady=10)
    submit_button.bind("<Enter>", on_enter)
    submit_button.bind("<Leave>", on_leave)

def process_manual_segmentation_action(low_thresh, high_thresh):
    global original_image, original_image_array

    if original_image is None:
        messagebox.showwarning("Warning", "Please upload an image first!")
        return

    try:
        processed_image_array = process_manual_segmentation(original_image_array, low_thresh, high_thresh)
        processed_image = Image.fromarray(processed_image_array)

        # Display processed image
        processed_image.thumbnail((300, 300))
        processed_image_tk = ImageTk.PhotoImage(processed_image)
        processed_image_label.configure(image=processed_image_tk, text="")  # Clear the text
        processed_image_label.image = processed_image_tk
    except Exception as e:
        messagebox.showerror("Error", f"Failed to process action: {e}")

# Update process_action to include Manual segmentation
def process_action(action):
    global original_image, original_image_array

    if original_image is None:
        messagebox.showwarning("Warning", "Please upload an image first!")
        return

    try:
        if action == "Grayscale":
            processed_image = manual_grayscale(original_image)
        elif action == "Add Image":
            processed_image_array = add(original_image_array)
            processed_image = Image.fromarray(processed_image_array)
        elif action == "Subtract Image":
            processed_image_array = subtract(original_image_array)
            processed_image = Image.fromarray(processed_image_array)
        elif action == "Invert Image":
            processed_image_array = invert(original_image_array)
            processed_image = Image.fromarray(processed_image_array)
        elif action == "Calculate Threshold":
            processed_image_array, threshold = calculate_threshold(original_image_array)
            optimal_threshold = 128
            tolerance = 10
            if abs(threshold - optimal_threshold) <= tolerance:
                threshold_message = f"Calculated Threshold: {threshold:.2f}\nThe threshold is optimal."
            else:
                threshold_message = f"Calculated Threshold: {threshold:.2f}\nThe threshold is not optimal."
            messagebox.showinfo("Threshold Result", threshold_message)
            processed_image = Image.fromarray(processed_image_array)
        elif action == "Simple Halftone":
            processed_image_array = simple_halftone(original_image)
            processed_image = Image.fromarray(processed_image_array)
        elif action == "Advanced Halftone":
            processed_image_array = advanced_halftone(original_image)
            processed_image = Image.fromarray(processed_image_array)
        elif action == "High-pass Filter":
            processed_image_array = conv(original_image_array, mask_high_pass)
            processed_image = Image.fromarray(processed_image_array)
        elif action == "Low-pass Filter":
            processed_image_array = conv(original_image_array, mask_low_pass)
            processed_image = Image.fromarray(processed_image_array)
        elif action == "Median Filter":
            processed_image_array = median_filter(original_image_array)
            processed_image = Image.fromarray(processed_image_array)
        elif action in ["Sobel", "Prewitt", "Kirsch"]:
            processed_image_array = apply_edge_detection(original_image, method=action)
            processed_image = Image.fromarray(processed_image_array)
        elif action == "Generate Histogram":
            display_histogram(original_image_array, title="Original Image Histogram")
            return
        elif action == "Equalize Histogram":
            equalized_image, equalized_array = histogram_equalization(original_image)
            display_histogram(equalized_array, title="Equalized Image Histogram")
            equalized_quality = analyze_histogram_quality(equalized_array)
            messagebox.showinfo("Equalization Result", f"Equalized Histogram Analysis:\n{equalized_quality}")
            processed_image = equalized_image

        elif action == "Manual":
            get_threshold_inputs()
            return

        elif action == "Homogeneity":
            processed_image_array = homogeneity_operator(original_image_array)
            processed_image = Image.fromarray(processed_image_array)
        elif action == "Difference":
            processed_image_array = difference_operator(original_image_array)
            processed_image = Image.fromarray(processed_image_array)
        elif action == "Difference of Gaussians":
            processed_image_array = difference_of_gaussians(original_image_array)
            processed_image = Image.fromarray(processed_image_array)
        elif action == "Contrast Edge Detection":
            processed_image_array = contrast_edge_detection(original_image_array)
            processed_image = Image.fromarray(processed_image_array)
        elif action == "Variance":
            processed_image_array = variance_operator(original_image_array)
            processed_image = Image.fromarray(processed_image_array)
        elif action == "Range":
            processed_image_array = range_operator(original_image_array)
            processed_image = Image.fromarray(processed_image_array)
            
        elif action == "Peak":
            processed_image_array = process_peak_technique(original_image_array)
            processed_image = Image.fromarray(processed_image_array)
            
        elif action == "Valley":
            processed_image_array = process_valley_technique(original_image_array)
            processed_image = Image.fromarray(processed_image_array)
            
        elif action == "Adaptive":
            processed_image_array = process_adaptive_histogram_technique(original_image_array)
            processed_image = Image.fromarray(processed_image_array)

        else:
            messagebox.showinfo("Info", f"{action} is not implemented yet.")
            return

        # Display processed image
        processed_image.thumbnail((300, 300))
        processed_image_tk = ImageTk.PhotoImage(processed_image)
        processed_image_label.configure(image=processed_image_tk, text="")  # Clear the text
        processed_image_label.image = processed_image_tk
    except Exception as e:
        messagebox.showerror("Error", f"Failed to process action: {e}")


# Function to change button appearance on hover
def on_enter(e):
    e.widget['background'] = '#5D3F6E'  # Cosmos purple shade
    e.widget['foreground'] = 'white'

def on_leave(e):
    e.widget['background'] = '#402C59'  # Darker purple shade
    e.widget['foreground'] = 'white'

# Main Window
root = tk.Tk()
root.title("Image Processing Toolbox")
root.geometry("1055x600")

# Cosmos color palette
background_color = "#2A1A44"
frame_bg_color = "#3C2A5A"
button_bg_color = "#5D3F6E"
button_active_bg_color = "#402C59"
label_fg_color = "#F1FAEE"
button_fg_color = "white"

# Frames
left_frame = tk.Frame(root, width=350, bg=frame_bg_color, relief="sunken", borderwidth=2)
left_frame.pack(side="left", fill="y")
right_frame = tk.Frame(root, bg=background_color)
right_frame.pack(side="right", expand=True, fill="both")

# Left Frame Content
image_label = tk.Label(left_frame, text="Uploaded Image", bg=frame_bg_color, font=("Helvetica", 12, "bold"), fg=label_fg_color)
image_label.pack(pady=10)
processed_image_label = tk.Label(left_frame, text="Processed Image", bg=frame_bg_color, font=("Helvetica", 12, "bold"), fg=label_fg_color)
processed_image_label.pack(pady=10)

upload_button = tk.Button(left_frame, text="Upload Image", command=upload_image, bg=button_bg_color, fg=button_fg_color, font=("Helvetica", 10, "bold"), relief="raised", activebackground=button_active_bg_color, activeforeground="white")
upload_button.pack(pady=20)
upload_button.bind("<Enter>", on_enter)
upload_button.bind("<Leave>", on_leave)

# Right Frame Content
sections = {
    "Basic Operations": ["Grayscale", "Calculate Threshold", "Simple Halftone", "Advanced Halftone"],
    "Histogram": ["Generate Histogram", "Equalize Histogram"],
    "Edge Detection": ["Sobel", "Prewitt", "Kirsch"],
    "Advanced Edge Detection": ["Homogeneity", "Difference", "Difference of Gaussians", "Contrast Edge Detection", "Variance", "Range"],
    "Filters": ["High-pass Filter", "Low-pass Filter", "Median Filter"],
    "Image Operations": ["Add Image", "Subtract Image", "Invert Image"],
    "Segmentation": ["Manual Segmentation", "Peak", "Valley", "Adaptive"]
}

for section, actions in sections.items():
    section_frame = tk.LabelFrame(right_frame, text=section, padx=10, pady=10, bg=frame_bg_color, font=("Helvetica", 12, "bold"), fg=label_fg_color)
    section_frame.pack(fill="x", pady=5, padx=10)
    for action in actions:
        action_button = tk.Button(
            section_frame,
            text=action,
            command=lambda a=action: process_action(a),
            bg="#402C59",
            fg=button_fg_color,
            font=("Helvetica", 10, "bold"),
            relief="raised",
            activebackground="#5D3F6E",
            activeforeground="white"
        )
        action_button.pack(side="left", padx=5, pady=5)
        action_button.bind("<Enter>", on_enter)
        action_button.bind("<Leave>", on_leave)

# Run Application
root.mainloop()
