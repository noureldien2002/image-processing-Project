import numpy as np
import matplotlib.pyplot as plt
from PIL import Image

def compute_histogram(image, num_bins=256):
    histogram = [0] * num_bins
    rows, cols = image.shape
    for i in range(rows):
        for j in range(cols):
            histogram[image[i, j]] += 1
    return np.array(histogram)

def find_peaks(histogram, min_spacing=10):
    peaks = []
    for i in range(1, len(histogram) - 1):
        # Check if current bin is a peak
        if histogram[i] > histogram[i - 1] and histogram[i] > histogram[i + 1]:
            peaks.append((i, histogram[i]))

    #apply spacing constraint
    peaks = sorted(peaks, key=lambda x: x[1], reverse=True)
    selected_peaks = []
    for peak in peaks:
        if not selected_peaks or all(abs(peak[0] - p[0]) >= min_spacing for p in selected_peaks):
            selected_peaks.append(peak)
        if len(selected_peaks) == 2: 
            break
    return selected_peaks

def determine_background_and_object(peaks, histogram):
    areas = [sum(histogram[max(0, p[0]-10):p[0]+10]) for p in peaks]
    
    if areas[0] > areas[1]:
        return peaks[0], peaks[1]
    else:
        return peaks[1], peaks[0]

def find_valley_between_peaks(histogram, peak1, peak2):
    start, end = sorted([peak1[0], peak2[0]])
    valley_index = start
    min_value = histogram[start]
    
    for i in range(start + 1, end):
        if histogram[i] < min_value:
            min_value = histogram[i]
            valley_index = i
            
    return valley_index

def apply_threshold(image, threshold, max_value=255):
    segmented = np.zeros_like(image)
    segmented[image >= threshold] = max_value
    segmented[image < threshold] = 0
    return segmented

def smooth_histogram(histogram, window_size=5):
    half_window = window_size // 2
    smoothed = np.zeros_like(histogram)
    for i in range(len(histogram)):
        start = max(0, i - half_window)
        end = min(len(histogram), i + half_window + 1)
        smoothed[i] = sum(histogram[start:end]) / (end - start)
    return smoothed


def process_valley_technique(image, min_spacing=10, smoothing_window=5):

    hist = compute_histogram(image)
    
    smoothed_histogram = smooth_histogram(hist, window_size=smoothing_window)

    peaks = find_peaks(smoothed_histogram, min_spacing)

    background_peak, object_peak = determine_background_and_object(peaks, smoothed_histogram)

    valley_threshold = find_valley_between_peaks(smoothed_histogram, background_peak, object_peak)

    segmented_image = apply_threshold(image, valley_threshold, 255)
    
    return segmented_image

