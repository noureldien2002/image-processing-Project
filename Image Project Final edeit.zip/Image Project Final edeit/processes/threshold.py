import numpy as np
from PIL import Image

def manual_grayscale(image):
    """
    Convert a PIL Image to grayscale using manual calculations.
    """
    image_array = np.array(image)  # Convert image to array

    # Ensure the image has only RGB channels
    if image_array.shape[-1] == 4:  # Remove alpha channel if present
        image_array = image_array[:, :, :3]

    # Convert to grayscale
    height, width, _ = image_array.shape
    grayscale_array = np.zeros((height, width), dtype=np.uint8)

    for i in range(height):
        for j in range(width):
            r, g, b = image_array[i, j]
            grayscale_value = int(0.2989 * r + 0.5870 * g + 0.1140 * b)
            grayscale_array[i, j] = grayscale_value

    return Image.fromarray(grayscale_array)  # Convert back to PIL Image


def calculate_threshold(image_array):
    """
    Calculate the threshold of an image manually by determining
    the average pixel value of the grayscale image.
    """
    height, width = image_array.shape
    total_pixel_value = 0
    num_pixels = height * width

    for i in range(height):
        for j in range(width):
            total_pixel_value += image_array[i, j]

    threshold = total_pixel_value / num_pixels

    # Determine if the threshold is optimal
    optimal_threshold = 128  # Example value for optimality
    if abs(threshold - optimal_threshold) <= 10:  # Example margin of 10
        print(f"The calculated threshold {threshold:.2f} is optimal.")
    else:
        print(f"The calculated threshold {threshold:.2f} is not optimal.")

    return image_array, threshold


