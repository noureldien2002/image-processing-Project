# processes/image_operations.py
from PIL import Image
import numpy as np

# Function to load an image
def open_image(file_path):
    img = Image.open(file_path)
    img_array = np.array(img, dtype=np.uint8)
    return img_array

# Function to add an image to its copy
def add(image):
    height, width = image.shape
    added_image = np.zeros((height, width), dtype=np.uint8)
    for i in range(height): 
        for j in range(width):
            added_image[i, j] = image[i, j] + image[i, j]
            added_image[i, j] = max(0, min(added_image[i, j], 255))
    return added_image
# Function to subtract an image from its copy
def subtract(image):
    height, width = image.shape
    subtracted_image = np.zeros((height, width), dtype=np.uint8)
    for i in range(height):
        for j in range(width):
            subtracted_image[i, j] = image[i, j] - image[i, j]
            subtracted_image[i, j] = max(0, min(subtracted_image[i, j], 255))
    return subtracted_image

# Function to invert an image
def invert(image):
    height, width = image.shape
    inverted_image = np.zeros((height, width), dtype=np.uint8)
    for i in range(height):
        for j in range(width):
            inverted_image[i, j] = 255 - image[i, j]
    return inverted_image
