import numpy as np
from PIL import Image

# دالة لتحويل الصورة إلى تدرجات الرمادي
def to_grayscale(image):
    gray_image = np.array(image.convert("L"))
    return gray_image

# دالة للقيام بعمليات الالتفاف (Convolution) يدويًا مع تحسينات في الـ Padding
def convolve(image, kernel):
    kernel_height, kernel_width = kernel.shape
    image_height, image_width = image.shape
    pad_h = kernel_height // 2
    pad_w = kernel_width // 2

    # إضافة حواف صفرية (Padding) للصورة
    padded_image = np.pad(image, ((pad_h, pad_h), (pad_w, pad_w)), mode='constant', constant_values=0)
    output = np.zeros_like(image)

    # تطبيق عملية الالتفاف
    for i in range(image_height):
        for j in range(image_width):
            region = padded_image[i:i+kernel_height, j:j+kernel_width]
            output[i, j] = np.sum(region * kernel)

    return output

# دالة للكشف عن الحواف باستخدام Sobel
def sobel_operator(image):
    sobel_x = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]])
    sobel_y = np.array([[-1, -2, -1], [0, 0, 0], [1, 2, 1]])

    grad_x = convolve(image, sobel_x)
    grad_y = convolve(image, sobel_y)

    # حساب التدرج باستخدام الجذر التربيعي
    grad = np.sqrt(grad_x**2 + grad_y**2)
    grad = np.clip(grad, 0, 255)

    # تحسين التباين عبر تقنيات مثل الـ Gaussian
    grad = (grad - np.min(grad)) / (np.max(grad) - np.min(grad)) * 255
    return grad.astype(np.uint8)

# دالة للكشف عن الحواف باستخدام Prewitt
def prewitt_operator(image):
    kernel_x = np.array([[-1, 0, 1], [-1, 0, 1], [-1, 0, 1]])
    kernel_y = np.array([[-1, -1, -1], [0, 0, 0], [1, 1, 1]])

    grad_x = convolve(image, kernel_x)
    grad_y = convolve(image, kernel_y)

    grad = np.sqrt(grad_x**2 + grad_y**2)
    grad = np.clip(grad, 0, 255)

    grad = (grad - np.min(grad)) / (np.max(grad) - np.min(grad)) * 255
    return grad.astype(np.uint8)

# دالة للكشف عن الحواف باستخدام Kirsch
def kirsch_operator(image):
    kirsch_masks = [
        np.array([[-3, -3, 5], [-3, 0, 5], [-3, -3, 5]]),  # North
        np.array([[-3, 5, 5], [-3, 0, 5], [-3, -3, -3]]),  # North-East
        np.array([[5, 5, 5], [-3, 0, -3], [-3, -3, -3]]),  # East
        np.array([[5, 5, -3], [5, 0, -3], [-3, -3, -3]]),  # South-East
        np.array([[5, -3, -3], [5, 0, -3], [5, -3, -3]]),  # South
        np.array([[-3, -3, -3], [5, 0, -3], [5, 5, -3]]),  # South-West
        np.array([[-3, -3, -3], [-3, 0, -3], [5, 5, 5]]),  # West
        np.array([[-3, -3, -3], [-3, 0, 5], [-3, 5, 5]]),  # North-West
    ]

    edge_directions = []
    for mask in kirsch_masks:
        filtered = convolve(image, mask)
        edge_directions.append(filtered)

    max_response = np.max(np.stack(edge_directions), axis=0)
    max_response = np.clip(max_response, 0, 255)

    max_response = (max_response - np.min(max_response)) / (np.max(max_response) - np.min(max_response)) * 255
    return max_response.astype(np.uint8)

# دالة لتطبيق الكشف عن الحواف بناءً على الطريقة المطلوبة
def apply_edge_detection(image, method="Sobel"):
    gray_image = to_grayscale(image)  # تحويل الصورة إلى تدرجات الرمادي

    if method == "Sobel":
        return sobel_operator(gray_image)
    elif method == "Prewitt":
        return prewitt_operator(gray_image)
    elif method == "Kirsch":
        return kirsch_operator(gray_image)
    else:
        raise ValueError("Unsupported edge detection method.")
