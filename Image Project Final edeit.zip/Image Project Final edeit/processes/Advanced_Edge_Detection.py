import cv2
import numpy as np

def homogeneity_operator(image):
    """Apply the homogeneity operator to an image."""
    kernel = np.array([[-1, -1, -1],
                       [-1,  8, -1],
                       [-1, -1, -1]])
    processed_image = cv2.filter2D(image, -1, kernel)
    return processed_image

def difference_operator(image):
    """Apply the difference operator to an image."""
    # Calculate horizontal and vertical gradients
    kernel_x = np.array([[1, -1]], dtype=np.float32)  # Horizontal gradient kernel
    kernel_y = np.array([[1], [-1]], dtype=np.float32)  # Vertical gradient kernel

    # Apply the kernels
    diff_x = cv2.filter2D(image, cv2.CV_64F, kernel_x)
    diff_y = cv2.filter2D(image, cv2.CV_64F, kernel_y)

    # Combine the gradients
    result = cv2.magnitude(diff_x, diff_y)

    # Normalize the result to 8-bit for display
    processed_image = cv2.normalize(result, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    return processed_image

def difference_of_gaussians(image):
    """Apply the Difference of Gaussians (DoG) to an image."""
    # Apply two Gaussian blurs with different kernel sizes
    gaussian1 = cv2.GaussianBlur(image, (5, 5), 0)
    gaussian2 = cv2.GaussianBlur(image, (9, 9), 0)
    processed_image = cv2.absdiff(gaussian1, gaussian2)

    # Normalize and convert to 8-bit for display
    processed_image = cv2.normalize(processed_image, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    return processed_image

def contrast_edge_detection(image):
    """Apply contrast-based edge detection using Canny edge detection."""
    processed_image = cv2.Canny(image, 50, 150)
    return processed_image

def variance_operator(image):
    """Apply variance-based edge detection to an image."""
    ksize = 7
    mean = cv2.GaussianBlur(image.astype(np.float32), (ksize, ksize), 0)
    mean_sq = cv2.GaussianBlur(image.astype(np.float32) ** 2, (ksize, ksize), 0)
    variance = mean_sq - (mean ** 2)
    processed_image = cv2.normalize(variance, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    return processed_image

def range_operator(image):
    """Apply range-based edge detection to an image."""
    ksize = 7
    kernel = np.ones((ksize, ksize), np.uint8)
    local_min = cv2.erode(image, kernel)
    local_max = cv2.dilate(image, kernel)
    processed_image = local_max - local_min
    return processed_image
