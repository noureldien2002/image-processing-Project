import numpy as np
from PIL import Image

def manual_grayscale(image):
    """
    Convert a PIL Image to grayscale using manual calculations.
    """
    image_array = np.array(image)  # Convert image to array
    
    if image_array.shape[-1] == 4:  # إذا كانت الصورة تحتوي على قناة ألفا (RGBA)
        image_array = image_array[:, :, :3]  # إزالة قناة ألفا

    # حساب القيم الرمادية
    grayscale_array = (0.2989 * image_array[:, :, 0] +
                       0.5870 * image_array[:, :, 1] +
                       0.1140 * image_array[:, :, 2]).astype(np.uint8)
    return grayscale_array

def halftoning(image_array):
    """
    Apply error diffusion halftoning to a grayscale image.
    """
    rows, cols = image_array.shape
    halftoned_image = np.zeros_like(image_array, dtype=np.uint8)

    for y in range(rows):
        for x in range(cols):
            old_pixel = image_array[y, x]
            new_pixel = 0 if old_pixel < 128 else 255
            halftoned_image[y, x] = new_pixel
            error = old_pixel - new_pixel            

            # Distribute the error to neighboring pixels (error diffusion)
            if x + 1 < cols:
                image_array[y, x + 1] += error * 7 / 16
            if y + 1 < rows and x > 0:
                image_array[y + 1, x - 1] += error * 3 / 16
            if y + 1 < rows:
                image_array[y + 1, x] += error * 5 / 16
            if y + 1 < rows and x + 1 < cols:
                image_array[y + 1, x + 1] += error * 1 / 16

    return halftoned_image

def advanced_halftone(image):
    """
    Convert the image to grayscale and apply advanced halftoning (error diffusion).
    """
    grayscale_image = manual_grayscale(image)  # Convert to grayscale
    halftoned_image = halftoning(grayscale_image)  # Apply halftoning
    return halftoned_image
