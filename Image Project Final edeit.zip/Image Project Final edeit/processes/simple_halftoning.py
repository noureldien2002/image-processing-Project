import numpy as np
from PIL import Image

def manual_grayscale(image):
    """
    Convert a PIL Image to grayscale using manual calculations.
    """
    image_array = np.array(image)  # Convert image to array
    
    if image_array.shape[-1] == 4:  # إذا كانت الصورة تحتوي على قناة ألفا (RGBA)
        image_array = image_array[:, :, :3]  # إزالة قناة ألفا

    # حساب القيم الرمادية
    grayscale_array = (0.2989 * image_array[:, :, 0] +
                       0.5870 * image_array[:, :, 1] +
                       0.1140 * image_array[:, :, 2]).astype(np.uint8)
    return grayscale_array


def halftoning(image_array):
    """
    Apply simple halftoning (binarization) to a grayscale image.
    """
    rows, cols = image_array.shape
    halftoned_image = np.zeros_like(image_array, dtype=np.uint8)

    for y in range(rows):
        for x in range(cols):
            old_pixel = image_array[y, x]
            new_pixel = 0 if old_pixel < 128 else 255
            halftoned_image[y, x] = new_pixel

    return halftoned_image


def simple_halftone(image):
    """
    Convert the image to grayscale and apply halftoning.
    """
    grayscale_image = manual_grayscale(image)  # Convert to grayscale
    halftoned_image = halftoning(grayscale_image)  # Apply halftoning
    return halftoned_image
