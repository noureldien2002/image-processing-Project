# processes/image_color.py
from PIL import Image
import numpy as np

def manual_grayscale(image):
    # Convert the image to a NumPy array
    image_array = np.array(image)

    # Check if the image has an alpha channel
    if image_array.shape[-1] == 4:  # RGBA
        image_array = image_array[:, :, :3]  # Ignore alpha channel

    # Calculate grayscale values using the weighted formula
    grayscale_array = (0.2989 * image_array[:, :, 0] +
                       0.5870 * image_array[:, :, 1] +
                       0.1140 * image_array[:, :, 2]).astype(np.uint8)

    # Convert the grayscale array back to an image
    grayscale_image = Image.fromarray(grayscale_array)

    return grayscale_image
